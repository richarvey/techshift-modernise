const AWS = require('aws-sdk');

async function bufferToS3(s3, bucket, src, dest) {
    try {
        await s3.upload({
            Bucket: bucket,
            Key: dest,
            Body: src
        }).promise();
    } catch (err) {
        console.log(err);
    }
}

async function bufferFromS3(s3, bucket, src) {
    try {
        var result = await s3.getObject({ 
            Bucket: bucket, 
            Key: src 
        }).promise();
        return result.Body;
    } catch (err) {
        console.log(err);
        return null;
    }
}

async function generateThumb(item) {
    try {
        AWS.config.update({ region: item.region });
        var s3 = new AWS.S3({apiVersion: '2006-03-01'});
        
        console.log("Generating Thumbnail for Item: " + item.uri);
        var contents = await bufferFromS3(s3, item.s3Bucket, item.uri);

        const sharp = require('sharp');
        var thumb = await sharp(contents)
            .resize({
                width: 200,
                height: 200,
                fit: sharp.fit.inside
            })
            .toBuffer();

        await bufferToS3(s3, item.s3Bucket, thumb, item.thumburi);    
        return true;
    } catch (err) {
        console.log(err);
        return false;
    }
}

async function queueHelper(items, func) {
    //Assume that all the records are correctly handled
    var recordsDone = true;
    for (var i=0; i < items.length; i++) {
        var record = items[i];
        var body = JSON.parse(record.body);
        var recordDone = false;
        if (body != null) {
            recordDone = await func(body);
        } else {
            //Just delete badly formed queue items
            recordDone = true;
        }
        if (!recordDone) {
            //If this record failed, then the batch failed
            recordsDone = false;
        }
    }

    return recordsDone;
}

exports.handler = async (event, context, callback) => {
    var ok = await queueHelper(event.Records, generateThumb);
    if (ok) {
        callback(null, "Batch Processed - Success");
    } else {
        callback("Batch Processed - Failed", null); 
    }
}