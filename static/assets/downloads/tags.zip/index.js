const AWS = require('aws-sdk');

async function bufferFromS3(s3, bucket, src) {
    try {
        var result = await s3.getObject({ 
            Bucket: bucket, 
            Key: src 
        }).promise();
        return result.Body;
    } catch (err) {
        console.log(err);
        return null;
    }
}

async function generateTags(item) {
    try {
        console.log("Generating Tags for Item: " + item.uri);

        //Get file from S3
        AWS.config.update({ region: item.region });
        var s3 = new AWS.S3({apiVersion: '2006-03-01'});
        var contents = await bufferFromS3(s3, item.s3Bucket, item.uri);
        console.log("Downloaded file " + item.s3Bucket + "/" + item.uri + ". Total size: " + contents.length + " bytes.");
        
        //Upload to Rekognition. Cannot refer to S3 bucket in another region.
        AWS.config.update({ region: 'ap-southeast-2' });
        var rekognition = new AWS.Rekognition();
        var results = await rekognition.detectLabels({
            Image: { Bytes: contents }, 
            MaxLabels: 6
        }).promise();

        var labels = results.Labels.map(x => x.Name);
        console.log("Rekognition returned: " + JSON.stringify(labels));
        
        //Call the update function
        var callbackBody = {
            sessionId: item.sessionId,
            tags: labels.join(","),
            imageId: item.imageId
        };

        const request = require('request-promise-native');
        try {
            const response = await request({
                method: 'PUT',
                uri: item.callback,
                body: callbackBody,
                json: true
            });
            console.log(JSON.stringify(response));
            return true;
        }
        catch (error) {
        console.log("An error occured: ", error);
        return false;
        }

    } catch (err) {
        console.log(err);
        return false;
    }
}

async function queueHelper(items, func) {
    //Assume that all the records are correctly handled
    var recordsDone = true;
    for (var i=0; i < items.length; i++) {
        var record = items[i];
        var body = JSON.parse(record.body);
        var recordDone = false;
        if (body != null) {
            recordDone = await func(body);
        } else {
            //Just delete badly formed queue items
            recordDone = true;
        }
        if (!recordDone) {
            //If this record failed, then the batch failed
            recordsDone = false;
        }
    }

    return recordsDone;
}

exports.handler = async (event, context, callback) => {
    var ok = await queueHelper(event.Records, generateTags);
    if (ok) {
        callback(null, "Batch Processed - Success");
    } else {
        callback("Batch Processed - Failed", null); 
    }
}